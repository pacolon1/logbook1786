package com.manh1786.simplecalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // 1. Khai báo các biến cho các thành phần giao diện
    private EditText etOperand1, etOperand2;
    private TextView tvResult;
    private Button btnAdd, btnSubtract, btnMultiply, btnDivide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 2. Ánh xạ các biến với ID trong file layout XML
        etOperand1 = findViewById(R.id.et_operand1);
        etOperand2 = findViewById(R.id.et_operand2);
        tvResult = findViewById(R.id.tv_result);
        btnAdd = findViewById(R.id.btn_add);
        btnSubtract = findViewById(R.id.btn_subtract);
        btnMultiply = findViewById(R.id.btn_multiply);
        btnDivide = findViewById(R.id.btn_divide);

        // 3. Đăng ký sự kiện onClick cho tất cả các nút
        btnAdd.setOnClickListener(this);
        btnSubtract.setOnClickListener(this);
        btnMultiply.setOnClickListener(this);
        btnDivide.setOnClickListener(this);
    }

    // 4. Xử lý sự kiện khi một nút được nhấn
    @Override
    public void onClick(View v) {
        String operand1Str = etOperand1.getText().toString();
        String operand2Str = etOperand2.getText().toString();

        // Kiểm tra xem người dùng đã nhập đủ số chưa
        if (operand1Str.isEmpty() || operand2Str.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double operand1 = Double.parseDouble(operand1Str);
            double operand2 = Double.parseDouble(operand2Str);
            double result = 0.0;

            // Xác định nút nào được nhấn và thực hiện phép tính tương ứng
            int viewId = v.getId();
            if (viewId == R.id.btn_add) {
                result = operand1 + operand2;
            } else if (viewId == R.id.btn_subtract) {
                result = operand1 - operand2;
            } else if (viewId == R.id.btn_multiply) {
                result = operand1 * operand2;
            } else if (viewId == R.id.btn_divide) {
                // Xử lý trường hợp chia cho 0
                if (operand2 == 0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                    return;
                }
                result = operand1 / operand2;
            }

            // 5. Hiển thị kết quả lên TextView
            tvResult.setText("Result: " + result);

        } catch (NumberFormatException e) {
            // Xử lý nếu người dùng nhập không phải là số
            Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
        }
    }
}
