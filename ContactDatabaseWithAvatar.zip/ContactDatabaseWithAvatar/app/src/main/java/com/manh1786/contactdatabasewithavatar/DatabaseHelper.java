package com.manh1786.contactdatabasewithavatar; // Thay package name của bạn

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "contactsManager";
    private static final String TABLE_CONTACTS = "contacts";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_PHONE = "phone_number";
    private static final String KEY_AVATAR = "avatar_id"; // CỘT MỚI: Lưu ID ảnh

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Tạo bảng
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_CONTACTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_NAME + " TEXT,"
                + KEY_PHONE + " TEXT,"
                + KEY_AVATAR + " INTEGER" + ")"; // CỘT AVATAR MỚI
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    // Nâng cấp cơ sở dữ liệu (quan trọng nếu bạn thay đổi cấu trúc bảng)
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        onCreate(db);
    }

    // Thêm liên hệ mới
    public void addContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PHONE, contact.getPhone());
        values.put(KEY_AVATAR, contact.getAvatarId()); // LƯU ID ẢNH

        db.insert(TABLE_CONTACTS, null, values);
        db.close();
    }

    // Lấy tất cả liên hệ (có ID ảnh)
    public List<Contact> getAllContacts() {
        List<Contact> contactList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_CONTACTS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Contact contact = new Contact(
                        cursor.getInt(0), // ID
                        cursor.getString(1), // Name
                        cursor.getString(2), // Phone
                        cursor.getInt(3)  // Avatar ID
                );
                contactList.add(contact);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return contactList;
    }

    // ... Thêm các hàm updateContact, deleteContact, getContact nếu cần ...
    // (Bổ sung: Khi cập nhật hoặc lấy liên hệ, phải bao gồm KEY_AVATAR)
}