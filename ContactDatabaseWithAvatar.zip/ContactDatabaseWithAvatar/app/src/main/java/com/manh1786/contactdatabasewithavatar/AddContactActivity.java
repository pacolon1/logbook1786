package com.manh1786.contactdatabasewithavatar;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class AddContactActivity extends AppCompatActivity {

    private EditText etName, etPhone;
    private Button btnSave;
    private DatabaseHelper db;

    private ImageView imgDefault, imgMale, imgFemale;
    private ImageView[] avatarImages;

    private int selectedAvatarId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        db = new DatabaseHelper(this);

        // Ánh xạ các View
        etName = findViewById(R.id.et_name);
        etPhone = findViewById(R.id.et_phone);
        btnSave = findViewById(R.id.btn_save_contact);
        imgDefault = findViewById(R.id.img_avatar_default);
        imgMale = findViewById(R.id.img_avatar_male);
        imgFemale = findViewById(R.id.img_avatar_female);

        avatarImages = new ImageView[]{imgDefault, imgMale, imgFemale};

        // --- SỬA LỖI CHÍNH NẰM Ở ĐÂY ---
        View.OnClickListener avatarSelector = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Thay vì dựa vào tag, chúng ta sẽ dựa vào ID của ImageView được nhấn.
                // Điều này đáng tin cậy hơn trên mọi phiên bản Android.
                int viewId = v.getId();
                if (viewId == R.id.img_avatar_default) {
                    selectedAvatarId = R.drawable.avatar_default;
                } else if (viewId == R.id.img_avatar_male) {
                    selectedAvatarId = R.drawable.avatar_male;
                } else if (viewId == R.id.img_avatar_female) {
                    selectedAvatarId = R.drawable.avatar_female;
                }

                // Sau khi có ID, cập nhật giao diện
                highlightAvatar((ImageView) v);
            }
        };
        // --- KẾT THÚC PHẦN SỬA LỖI ---

        imgDefault.setOnClickListener(avatarSelector);
        imgMale.setOnClickListener(avatarSelector);
        imgFemale.setOnClickListener(avatarSelector);

        // Xử lý nút Lưu
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveContact();
            }
        });

        // Khởi tạo trạng thái ban đầu: chọn ảnh default và gán ID
        highlightAvatar(imgDefault);
        selectedAvatarId = R.drawable.avatar_default; // Gán trực tiếp ID drawable mặc định
    }

    private void highlightAvatar(ImageView selectedImage) {
        for (ImageView image : avatarImages) {
            image.setBackground(null); // Xóa viền của tất cả
        }
        // Thêm viền cho ảnh được chọn
        selectedImage.setBackgroundResource(R.drawable.avatar_selector_border);
    }

    private void saveContact() {
        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();

        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please enter both name and phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedAvatarId == 0) {
            Toast.makeText(this, "Please select an avatar.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Gọi đúng constructor (3 tham số) cho liên hệ mới
        Contact newContact = new Contact(name, phone, selectedAvatarId);

        db.addContact(newContact);

        Toast.makeText(this, "Contact saved successfully!", Toast.LENGTH_SHORT).show();

        setResult(RESULT_OK);
        finish();
    }
}
