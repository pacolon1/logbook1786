package com.manh1786.contactdatabasewithavatar; // Thay package name của bạn

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int ADD_CONTACT_REQUEST_CODE = 1; // Mã yêu cầu
    private DatabaseHelper db;
    private ContactAdapter adapter;
    private RecyclerView recyclerView;
    private Button btnAddContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.rv_contacts);
        btnAddContact = findViewById(R.id.btn_add_contact);

        // Khởi tạo danh sách nếu CSDL trống
        if (db.getAllContacts().isEmpty()) {
            addInitialContacts();
        }

        // Thiết lập RecyclerView
        List<Contact> contacts = db.getAllContacts();
        adapter = new ContactAdapter(contacts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Xử lý nút thêm: Mở AddContactActivity
        btnAddContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddContactActivity.class);
                // Sử dụng startActivityForResult để biết khi nào AddContactActivity đóng
                startActivityForResult(intent, ADD_CONTACT_REQUEST_CODE);
            }
        });
    }

    // Hàm này được gọi khi AddContactActivity đóng
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_CONTACT_REQUEST_CODE && resultCode == RESULT_OK) {
            // Nếu có liên hệ mới được thêm thành công, làm mới danh sách
            refreshContactList();
        }
    }

    // Hàm cập nhật danh sách liên hệ từ CSDL
    private void refreshContactList() {
        if (adapter != null) {
            adapter.setContactList(db.getAllContacts());
        }
    }

    // Hàm thêm 2 liên hệ mẫu với Avatar ID
    private void addInitialContacts() {
        // Đảm bảo bạn có các file này trong drawable: avatar_female, avatar_male
        db.addContact(new Contact(0, "Linh Nguyen", "0901234567", R.drawable.avatar_female));
        db.addContact(new Contact(0, "Minh Tran", "0917654321", R.drawable.avatar_male));
        // Sau khi thêm, danh sách sẽ tự động được load trong onCreate()
    }
}