package com.manh1786.contactdatabasewithavatar;

public class Contact {
    private int id;
    private String name;
    private String phone;
    private int avatarId;

    // --- CONSTRUCTORS ---

    // Constructor (3 tham số) DÙNG ĐỂ TẠO LIÊN HỆ MỚI
    // Sẽ được gọi từ AddContactActivity
    public Contact(String name, String phone, int avatarId) {
        this.name = name;
        this.phone = phone;
        this.avatarId = avatarId;
    }

    // Constructor (4 tham số) DÙNG ĐỂ ĐỌC LIÊN HỆ TỪ DATABASE
    // Sẽ được gọi từ DatabaseHelper
    public Contact(int id, String name, String phone, int avatarId) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.avatarId = avatarId;
    }

    // --- GETTERS AND SETTERS ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public int getAvatarId() { return avatarId; }
    public void setAvatarId(int avatarId) { this.avatarId = avatarId; }
}
