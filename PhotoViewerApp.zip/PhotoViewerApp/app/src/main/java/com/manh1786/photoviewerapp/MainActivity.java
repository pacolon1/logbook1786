package com.manh1786.photoviewerapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageView ivImageDisplay;
    private Button btnPrevious, btnNext;



    private int[] imageIds = {
            R.drawable.image_1,
            R.drawable.image_2,
            R.drawable.image_3,
            R.drawable.image_4,
            R.drawable.image_5,

    };

    private int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ivImageDisplay = findViewById(R.id.iv_image_display);
        btnPrevious = findViewById(R.id.btn_previous);
        btnNext = findViewById(R.id.btn_next);


        updateImage();


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                currentIndex++;

                if (currentIndex >= imageIds.length) {
                    currentIndex = 0;
                }
                updateImage();
            }
        });


        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                currentIndex--;

                if (currentIndex < 0) {
                    currentIndex = imageIds.length - 1;
                }
                updateImage();
            }
        });
    }


    private void updateImage() {
        if (imageIds.length > 0) {

            ivImageDisplay.setImageResource(imageIds[currentIndex]);

            Toast.makeText(this, "Showing image " + (currentIndex + 1) + " of " + imageIds.length, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No images found in the array.", Toast.LENGTH_LONG).show();
        }
    }
}